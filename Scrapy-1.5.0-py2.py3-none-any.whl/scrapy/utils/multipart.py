"""
Transitional module for moving to the w3lib library.

For new code, always import from w3lib.form instead of this module
"""

from w3lib.form import *
